-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 23, 2024 at 03:45 PM
-- Server version: 10.1.38-MariaDB
-- PHP Version: 5.6.40

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `carrental`
--

-- --------------------------------------------------------

--
-- Table structure for table `car_reg`
--

CREATE TABLE `car_reg` (
  `id` int(11) NOT NULL,
  `car_reg` varchar(255) NOT NULL,
  `make` varchar(255) NOT NULL,
  `model` varchar(255) NOT NULL,
  `available` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `car_reg`
--

INSERT INTO `car_reg` (`id`, `car_reg`, `make`, `model`, `available`) VALUES
(3, 'A0003', 'Honda', 'Fit6', 'No'),
(4, 'A0004', 'Honda', 'Fit7', 'No'),
(5, 'A0005', 'Honda', 'Swift', 'No'),
(6, 'A0006', 'honda', 'swift2', 'Yes'),
(7, 'A0007', 'Honda', 'Fit4', 'No'),
(8, 'A0008', 'Honda', 'swift', 'No'),
(9, 'A0009', 'Honda', 'Swift3', 'No'),
(10, 'A0010', 'honda', 'fit6', 'Yes'),
(11, 'A0011', 'honda', 'fit5', 'Yes'),
(12, 'A0012', 'honda', 'fit4', 'Yes'),
(13, 'A0013', 'honda', 'swift3', 'Yes'),
(14, 'A0013', 'honda', 'fit5', 'Yes'),
(15, 'A0014', 'hinda', 'fit6', 'Yes'),
(16, 'A0015', 'honda', 'fit6', 'Yes'),
(17, 'A0016', 'honda', 'fit4', 'Yes'),
(18, 'A0017', 'honda', 'fit4', 'Yes'),
(19, 'A0018', 'honda', 'fit4', 'Yes');

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `id` int(11) NOT NULL,
  `cust_id` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `NID` int(16) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`id`, `cust_id`, `name`, `address`, `NID`) VALUES
(1, 'C0001', 'adit ', 'kazla (01719289854)', 1178945677),
(2, 'C0002', 'Nimal', 'kazla (01719209854)', 2134234784),
(3, 'C0003', 'rakib', 'talaimary (01799289854)', 456789034),
(4, 'C0004', 'hasan', 'kazla (01719489854)', 456789653),
(9, 'C0005', 'tahar', 'talaimary (01740264670)', 2078654),
(10, 'C0005', 'taher', 'talaimary (01740264770)', 209876543),
(11, 'C0006', 'abrar', 'talaimary (01740264660)', 12567846),
(12, 'C0007', 'abul', 'Uposohor(017279900997)', 167889765),
(13, 'C0008', 'nishat', 'uposohor(01734577686)', 12345879),
(14, 'C0009', 'Tasnim', 'kazla(01785868686)', 123457575),
(15, 'C0010', 'sattar', 'kazla(01358927382)', 12345665);

-- --------------------------------------------------------

--
-- Table structure for table `rental`
--

CREATE TABLE `rental` (
  `id` int(11) NOT NULL,
  `car_id` varchar(255) NOT NULL,
  `cust_id` varchar(255) NOT NULL,
  `fee` int(11) NOT NULL,
  `date` varchar(255) NOT NULL,
  `due` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `rental`
--

INSERT INTO `rental` (`id`, `car_id`, `cust_id`, `fee`, `date`, `due`) VALUES
(25, 'A0009', 'C0001', 4000, '2024-01-17', '2024-01-22');

-- --------------------------------------------------------

--
-- Table structure for table `returncar`
--

CREATE TABLE `returncar` (
  `id` int(11) NOT NULL,
  `car_id` varchar(255) NOT NULL,
  `cust_id` varchar(255) NOT NULL,
  `return_date` varchar(255) NOT NULL,
  `elp` int(11) NOT NULL,
  `fine` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `returncar`
--

INSERT INTO `returncar` (`id`, `car_id`, `cust_id`, `return_date`, `elp`, `fine`) VALUES
(1, 'A0009', 'C0001', '2024-01-19', 0, 0),
(16, 'A0010', 'C0003', '2024-01-22', 0, 0),
(17, 'A0006', 'C0004', '2024-01-22', 2, 1400),
(18, 'A0014', 'C0006', '2024-01-23', 0, 0),
(19, 'A0016', 'C0008', '2024-01-22', 0, 0),
(20, 'A0017', 'C0009', '2024-01-23', 1, 700),
(21, 'A0018', 'C0010', '2024-01-22', 0, 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `car_reg`
--
ALTER TABLE `car_reg`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `rental`
--
ALTER TABLE `rental`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `returncar`
--
ALTER TABLE `returncar`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `car_reg`
--
ALTER TABLE `car_reg`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `customer`
--
ALTER TABLE `customer`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `rental`
--
ALTER TABLE `rental`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;

--
-- AUTO_INCREMENT for table `returncar`
--
ALTER TABLE `returncar`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
